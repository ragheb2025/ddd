from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.core.window import Window
from kivy.core.text import LabelBase
import openpyxl
from datetime import datetime
import os
import arabic_reshaper
from bidi.algorithm import get_display

# استخدام خط موجود على الجهاز يدعم العربية
LabelBase.register(name="ArabicFont", fn_regular="C:\\Windows\\Fonts\\tahoma.ttf")

def arabic(text):
    """تشكيل النص العربي وربطه من اليمين لليسار"""
    reshaped_text = arabic_reshaper.reshape(text)
    bidi_text = get_display(reshaped_text)
    return bidi_text

class ExpenseApp(App):
    def build(self):
        self.balance = 0
        self.records = []

        self.layout = BoxLayout(orientation='vertical', padding=10, spacing=10)

        # عرض الرصيد باللون الأحمر وحجم الخط 20
        self.balance_label = Label(
            text=arabic(f"الرصيد الحالي: {self.balance}"),
            size_hint_y=None,
            height=40,
            font_name="ArabicFont",
            font_size=20,
            color=(1, 0, 0, 1)  # أحمر
        )
        self.layout.add_widget(self.balance_label)

        # إدخال المبلغ
        self.amount_input = TextInput(
            hint_text=arabic("أدخل المبلغ"),
            multiline=False,
            input_filter="float",
            size_hint_y=None,
            height=40,
            font_name="ArabicFont"
        )
        self.layout.add_widget(self.amount_input)

        # إدخال البيان
        self.note_input = TextInput(
            hint_text=arabic("البيان (يمكن كتابة البيان بالعربية)"),
            multiline=False,
            size_hint_y=None,
            height=40,
            font_name="ArabicFont"
        )
        self.layout.add_widget(self.note_input)

        # أزرار المصروف والمقبوض
        btn_layout = BoxLayout(size_hint_y=None, height=40, spacing=10)
        expense_btn = Button(text=arabic("إضافة مصروف"), font_name="ArabicFont")
        expense_btn.bind(on_press=self.add_expense)
        income_btn = Button(text=arabic("إضافة مقبوض"), font_name="ArabicFont")
        income_btn.bind(on_press=self.add_income)
        btn_layout.add_widget(expense_btn)
        btn_layout.add_widget(income_btn)
        self.layout.add_widget(btn_layout)

        # ScrollView لسجل العمليات
        self.scroll = ScrollView(size_hint=(1, 1))
        self.records_label = Label(
            text="", 
            size_hint_y=None, 
            halign="right",
            valign="top",
            font_name="ArabicFont"
        )
        self.records_label.bind(texture_size=self.update_label_height)
        self.records_label.text_size = (self.scroll.width, None)
        self.scroll.add_widget(self.records_label)
        self.layout.add_widget(self.scroll)

        # أزرار التصدير والإغلاق
        bottom_btn_layout = BoxLayout(size_hint_y=None, height=40, spacing=10)
        export_btn = Button(text=arabic("تصدير إلى Excel"), background_color=(0,0.5,1,1), font_name="ArabicFont")
        export_btn.bind(on_press=self.export_excel)
        close_btn = Button(text=arabic("إغلاق التطبيق"), background_color=(1,0,0,1), font_name="ArabicFont")
        close_btn.bind(on_press=self.close_app)
        bottom_btn_layout.add_widget(export_btn)
        bottom_btn_layout.add_widget(close_btn)
        self.layout.add_widget(bottom_btn_layout)

        return self.layout

    def update_label_height(self, instance, value):
        instance.height = instance.texture_size[1]

    def add_expense(self, instance):
        self.add_record("مصروف")

    def add_income(self, instance):
        self.add_record("مقبوض")

    def add_record(self, type_):
        try:
            amount = float(self.amount_input.text)
            note = self.note_input.text
            now = datetime.now().strftime("%Y-%m-%d %H:%M")
            record_text = f"{type_}: {amount} - {note} ({now})"
            self.records.append(record_text)
            self.update_balance()
            self.update_records()
        except:
            self.balance_label.text = arabic("⚠️ يرجى إدخال رقم صحيح للمبلغ")

    def update_balance(self):
        self.balance = 0
        for record in self.records:
            type_, rest = record.split(":", 1)
            amount = float(rest.split("-")[0].strip())
            if type_ == "مصروف":
                self.balance -= amount
            else:
                self.balance += amount
        self.balance_label.text = arabic(f"الرصيد الحالي: {self.balance}")
        self.amount_input.text = ""
        self.note_input.text = ""

    def update_records(self):
        connected_records = [arabic(f"{i+1}. {r}") for i, r in enumerate(self.records)]
        self.records_label.text = "\n".join(connected_records)

    def export_excel(self, instance):
        if not self.records:
            self.balance_label.text = arabic("⚠️ لا يوجد بيانات للتصدير")
            return
        
        download_folder = os.path.expanduser("~/Downloads")
        if not os.path.exists(download_folder):
            os.makedirs(download_folder)
        file_name = f"تقرير_المصاريف_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        file_path = os.path.join(download_folder, file_name)

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "تقرير المصاريف"
        ws.append(["التاريخ والوقت", "النوع", "المبلغ", "البيان"])

        for record in self.records:
            type_, rest = record.split(":", 1)
            amount = float(rest.split("-")[0].strip())
            note_and_time = "-".join(rest.split("-")[1:]).strip()
            ws.append([note_and_time.split("(")[-1].strip(")"), type_, amount, note_and_time.split("(")[0].strip()])

        wb.save(file_path)
        self.balance_label.text = arabic(f"تم التصدير إلى {file_path}")

    def close_app(self, instance):
        App.get_running_app().stop()
        Window.close()

if __name__ == "__main__":
    ExpenseApp().run()
